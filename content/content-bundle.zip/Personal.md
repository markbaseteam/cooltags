---
Status: Now
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]

# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
# Personal
## Home Related
- [ ] Health Insurance (Ideas:: #Personal/Home) #NotATask
------------------------------------ 
- [ ] Visit Medall for a cardiologist appointment and decide on the next steps
- [ ] Ask Deepa and renew the health insurance

## Disconnect Airtel
- [ ] Disconnect Airtel (Ideas:: #Personal/Home) #NotATask
------------------------------------ 
- [ ]   Government ID
    - [ ] Aadhar
    - [ ] PAN Card
    - [ ] IEC Code
    - [X] GST [completion:: 2022-04-09]
    - [ ] Income Tax website
    - [x] Driver's License July 3, 2021
- [ ]   Wallets
    - [X] Phonepe Wallet [completion:: 2022-04-08]
    - [ ] GPay Wallet 
    - [ ] CRED Wallet
- [ ]   Home Appliances
    - [ ] Call Onida for Mobile Number change and Service
    - [ ] Call Hitachi for Mobile Number change and Service
    - [ ] Call Haier TV(Old and New) for Mobile Number change
    - [X] Call Policy Bazaar for mobile number change [completion:: 2022-04-08]
    - [ ] GoDaddy
- [ ]   Chettinad School
    - [ ] Check with School management on where to change the mobile number 
- [X] Insurance [completion:: 2022-04-08]
    - [X] Car Insurance [completion:: 2022-04-08]
    - [X] Bike Insurance [completion:: 2022-04-08]
- [X] Online Shopping [completion:: 2022-04-08]
    - [X] Amazon [completion:: 2022-04-08]
    - [X] JioMart [completion:: 2022-04-08]
    - [X] BigBasket [completion:: 2022-04-08]
    - [X] Grofers [completion:: 2022-04-08]
- [X] Axis Bank [completion:: 2022-04-08]
    - [X] Axis Flipkart Credit Card [completion:: 2022-04-08]
- [ ]   ICICI Bank
    - [X] ICICI Amazon Credit Card [completion:: 2022-04-19]
    - [ ] ICICI Credit Card
    - [x] ICICI UPI Handle [--:: 2022-01-24] ✅ 2022-01-24
    - [x] ICICI Savings [--:: 2022-01-27]
- [ ]   HSBC Bank
     - [ ] HSBC Credit Cards
- [ ]   SBI Bank
    - [ ] SBI Credit Card
    - [ ] SBI UPI Handle
    - [ ] SBI Savings YONO
    - [ ] SBI Current
- [ ]   HDFC Bank
    - [ ] HDFC Credit Cards
    - [ ] HDFC UPI Handle
    - [ ] HDFC Joint Savings
    - [ ] HDFC Shruti Savings Account
- [ ]   TMB
    - [ ] TMB Current
- [ ]   Kotak Bank
    - [ ] Kotak UPI Handle
    - [ ] Kotak Bank
- [X] Amazon [completion:: 2022-04-08]
    - [X] Amazon Pay UPI Handle [completion:: 2022-04-08]
- [ ]   Paytm
    - [ ] Paytm UPI Handle
    - [ ] Paytm Wallet
    - [ ] Paytm Savings Bank
- [ ]  Jiopay
## Home Appliances
- [ ] Home Appliances (Ideas:: #Personal/Home) #NotATask
------------------------------------ 
- [ ] Toshiba Computer (Talent Computers) 🗓️ 2022-05-06
	- [ ] Call Talent Computers 
- [ ] Call Haier Rajasekhar for AMC Renewal 🗓️ 2022-05-06
- [ ] Visit RTO for Scorpio RC Renewal 🗓️ 2022-05-06

## GST & Taxes
- [ ] GST & Taxes (Ideas:: #Personal/Taxes) #NotATask
------------------------------------ 
- [ ] Pay GST Monthly & Quarterly Taxes 🗓️ 2022-05-04

## Banks & Mutual Funds
- [ ] Banks & Mutual Funds (Ideas:: #Personal/Finance) #NotATask
------------------------------------ 
- [ ] SBI Current Annual Charges
	- [ ] Visit Bank to know about the charges
- [ ] TMB Documents
	- [ ] Verify the Documents at home
		- [ ] Submit the documents to register office and fix the time
			- [ ] Submit the documents to register office and fix the time
			- [ ] Visit the SR Agent and ask for documents needed
			- [ ] Ask for the steps to complete
		- [ ] Xerox the ids of manager and witness and land documents
		- [ ] Submit the documents to register office and fix the time
		- [ ] Visit the SR Agent and ask for documents needed 
		- [ ] Ask for the steps to complete
		- [ ] Xerox the ids of manager and witness and land documents
- [ ] Reset the TMB Password 🗓️ 2022-05-03
- [ ] Finish KYC for Vijaya Bank [[2022-Week 9]]
	- [ ] Visit Bank to know about the details
- [ ] Create an Account with Zerodha [[2022-Week 9]]

Potential Equity Funds - 80% (20K) ([LiveMint](https://www.livemint.com/money/personal-finance/keep-a-smart-flexible-and-minimalist-mf-portfolio-11638378827521.html)) [MoneyControl](https://www.moneycontrol.com/mutual-fund/mc-30)
    - Small Cap- 1
        - Nippon India Small Cap (OR) SBI Small Cap
    - Mid Cap - 1
        - Invesco India Mid Cap (OR) Axis Mid Cap
    - Aggressive Hybrid - 1
        - DSP Equity & Bond Aggressive Hybrid OR Edelweiss Balanced Advantage OR ICICI Prudential Balanced Advantage
    - Flexi Cap - 1
        - Parag Parikh Flexi (OR) Canara Robeco Flexi Cap
    - Large Cap Index - 2
        - UTI N1 (UTI NIFTY Index) OR HDFC Index
        - ICICI Prudential NIFTY Next 50
    - ELSS - 1
        - Axis Long Term Equity Fund OR Canara Robeco Equity Tax Saver OR Mirae Asset Tax Saver
    - Arbitrage - 0
        - Kotak Equity Arbitrage OR Tata Arbitrage
    - Equity
        1. Aggressive Hybrid Fund
        2. Flexi Cap funds
        3. Large-cap funds
        4. Large-&-Midcap Funds
        5. International Funds
        6. Midcap & Smallcap Funds
        Most [small cap funds](https://m.economictimes.com/mf/small-cap-mutual-funds) are able to beat the TRI benchmarks followed by mid cap schemes.
    - Examples
        1. Nippon India Growth fund
        2. Franklin Prima
        3. ICICI Prudential Technology fund
        4. SBI Magnum Global fund
        5. SBI Contra
Potential Debt Funds - 10% (2500)
	  2 funds
    1. SHORT TERM
        1. HDFC Corporate Bond OR IDFC Corporate Bond
    2. CREDIT RISK
        1. HDFC Credit Risk Debt OR ICICI Prudential Credit Risk
    3. DEBT (LESS THAN 1YEAR)
        1. HDFC Money Market OR Kotak Money Market
    - Debt
        1. Liquid
        2. Ultra-Short Duration funds
        3. Low Duration funds
        4. Short-Duration funds
        5. Money Market funds
        6. Banking and PSU funds
        7. Corporate Bond funds
Potential International Funds- 5% (1250)
    1 fund
Potential Gold Funds - 5% (1250)
# Imports
## Ideas
- [ ] Ideas (Ideas:: #Imports/Ideas) #NotATask
------------------------------------ 
- [ ] MSME around Chennai
	- [ ] Search online to Understand MSME clusters in Chennai
	- [ ] TANSIDCO 
		- [ ] Visit Website for more Information
		- [ ] Visit onsite to get Information on MSME clusters in Chennai
	   - [ ] Raw Materials needed for those Industries? What Raw materials are mostly imported?
- [ ] Commodity Exchanges
	- [ ]  Look at all the Commodity Exchanges in India
	   - [ ] Look at the Trading Commodities for any dominant Commodities in Tamil Nadu & Andhra
	   - [ ] Look at Commodity Exchanges in Asia and America
	   - [ ] Look at the Trading Commodities for any potential Tie-ups with India
- [ ] UAE
	- [ ] Read about FTA with UAE
[Singapore & Malaysia Import Data](https://docs.google.com/spreadsheets/d/1RFtsaapY5R-9szRo3qlAdZDCZyxb0cj0pE6caLSlUWk/edit#gid=0)
[Singapore & Malaysia Export Data](https://docs.google.com/spreadsheets/d/1w8WiCkqReSbk_mKwo9UGzbsGkSQUsDDSA4-CpoXQqP4/edit#gid=0)
Pepper & Dumping
	Sri Lanka is dumping Vietnam pepper in India. There have been occasions when pepper from Vietnam have come directly to India in ships with bills raised in Sri Lanka to show as if it was grown in the island nation. Since January, 2,759 tonnes of pepper has come from Sri Lanka with the value of imports pegged at Rs 7,000 per tonne. But going by the prices in the domestic market, the actual cost may not be higher than Rs 3,500 a tonne.“ Invoices are being shown at a higher value to beat around the minimum import price. Most of these shipments land in Chennai or Tuticorin ports. Buyers in these countries are importing it from Vietnam and then pushing it into India at a lower duty, taking advantage of the FTAs and other trade agreements.
LED Lights & Import Frauds
	Such operators either illegally import finished products from China or merely assemble imported parts in India -- reducing any requirement for Labour within the country. Second, since the illegal market evades taxes by definition, it results in a huge loss for the national exchequer. When more than half the market is unaccounted for, a $4 billion industry can be said to amount to at least twice that number. With a GST of 12 percent on LEDs, the loss in revenue should sum up to approximately $0.5 billion. [](https://www.business-standard.com/article/news-ians/government-should-wake-up-to-scourge-of-illegal-leds-comment-special-to-ians-117102000163_1.html)[https://www.business-standard.com/article/news-ians/government-should-wake-up-to-scourge-of-illegal-leds-comment-special-to-ians-117102000163_1.html](https://www.business-standard.com/article/news-ians/government-should-wake-up-to-scourge-of-illegal-leds-comment-special-to-ians-117102000163_1.html)
Fructose & Alibaba
	On checking India's Ministry of Commerce database, CSE found that the same Chinese companies listed on trade portals like Alibaba also exported to India. Some of these names that have exported 'fructose' to India in the last few years are Wuhu Runquin Daily Necessities, Wuhu Haoyikuai Import and Export (HYK foods), Wuhu Deli, Anhui Yuan Sen.  CSE said that from the trade base they found that in the last four years more than 11,000 MT of fructose syrup had come from these sellers as 'industrial raw material'. Buyers were from Punjab (Faridkot, Patiala and Rajpura); Delhi NCR; Jaspur and Kashipur (Uttarakhand). In fact, as per the database, the average quantity of fructose from China is over 10,000 MT every year since 2014-15. In 2012-2013, it was less than 2,500 MT.
Imports & Other Categories & Intermediate Countries
	For every product category, there is an “others” group, where items are not properly classified. An analysis undertaken by the commerce department showed that close to 80% of the imports under 10 segments were imported under the “others” category and their total value added up to $128 billion, which was a third of the shipments into the country. As much as 97% of the metal scrap entered via the others route during this period. Similarly, 60% of the auto components came in this segment, providing little information to the government on the kind of auto parts that came into the country. Chinese companies adding value add in other countries with FTA with India and importing to India finally to escape duties

## IEC
- [ ] IEC (Ideas:: #Imports/Regulations) #NotATask
------------------------------------ 
- [ ] Visit PAN Center
	- [ ]  Printout PAN - Aadhar Verification Image, XML File
	- [ ]  Take the Original Aadhar & Old & New PAN Cards and Duplicate PAN Card
	- [ ]  Change Password for PAN Website later 
- [ ] Identify IEC Agents
	- [ ] Search Google and Physical Streets to identify Agents
- [ ] Define the Topics to discuss
    - [ ] Should I update my PAN Name in IEC, if my PAN Name changes are successful?
- [ ] Is my IEC still Active?
    - [ ] Cost & Time to link IEC?