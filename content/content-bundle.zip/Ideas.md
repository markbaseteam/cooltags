---
Status: Now
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]] [[Contacts]] 

# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
# Agriculture
## Almonds and Dry Dates
- [ ] Almonds and Dry Dates (Ideas:: #Agriculture/DryNuts) #NotATask
------------------------------------ 
- [ ] ==Products== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Regulations== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Customers== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Channels== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Suppliers== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Business Model== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Financial== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Value Chain== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Delivery== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

# Industrial
## Paints
- [ ] Paints (Ideas:: #Industrial) #NotATask
------------------------------------ 
- [ ] ==Products== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 
	- [ ] Understand the Paint products
		- [ ] Browse Nippon Paints & Asian Paints
		- [ ] Browse Google Photos of Paints and note down important points
		- [ ] Paint Products in India
		- [ ] Paint Products Imported to India
		- [ ] Other Adjacent Paint Products Imported - Inputs, Outputs
	- [ ] HS Code for Paints
		- Not much Imports & Exports to Dubai
		- (https://www.cybex.in/hs-codes/tanning-dyeing-extracts-tannins-their-chapter-32.aspx)
	- [ ] Input Materials	
		- The paints industry uses crude oil derivatives such as titanium dioxide and monomers as raw materials
	- [ ] Product Types
			- Dulux Easy Clear
			- Dulux Pentalite Ceiling
			- Clariant - TS 600 - Tinting Paste
			- Herbol - Silatec - Acryloxan Technology - Weiss - Blanco
			- Akzo
			- Nobel - Dulux Pentalite

- [ ] ==Regulations== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 
	- [ ] Find out if BIS required for the HS code
		- [ ] BIS Certification is needed?
		- [ ] Download Import Data for HS Code for Paint
		- [ ] Know the HS code and understand the Importing Countries and which Seaport is commonly used?
		 - [ ]  Countries & Product Type?

- [ ] ==Customers== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 
	- [ ] Paints Industry
		- [ ] Google the Paint Name to know more about the Name, Availability
		- [ ] Are there any Traders in the Industry?
		- [ ] Google the Usage & Where it is used?
		- [ ] How big is the industry?

- [ ] ==Channels== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Suppliers== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Business Model== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Financial== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Value Chain== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Delivery== Week 20-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 
