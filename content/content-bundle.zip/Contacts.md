---
Status: Now
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]
# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
# Last Contacted
```dataview
TASK
FROM "Ideas/Contacts"
WHERE contains(text, "#Contacts")
WHERE !completed
sort Type ASC
sort  LastContacted ASC
```
# By Type
```dataview
TASK
FROM "Ideas/Contacts"
WHERE contains(text, "#Contacts")
WHERE !completed
GROUP BY Type
```

# Government Related
- [ ] ==Custom House==(Type:: Customs) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

1.  Praveen 9940164654. Custom House Statistical unit 3rd floor annexure building. He said that he will do it unofficially and will charge 2000 per eight digit HS code. One month of data with info on
2. importers and exporters and price and quantity and ports of shipment.
3.  Praveen has moved out. Cristo is in charge. 1500 per HS Code one month data 082481 88985
4. Who is importing, Who is exporting, at What price, How much quantity and from Where, Actual product description, HS code, Port or Country of Origin, Port or Country of destination, Date of Shipment.
## **==Government Related Archived==**

# General
- [ ] ==Magesh==(Type:: PCB) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask 

9444242432
5-6 Lakhs Fees for one-time Authorization
2 months Processing time



- [ ] ==VH Tax Consulting==(Type:: PCB ) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask 

1. Processing time 7-10 days
2. If no Godown and directly sending to the Customer, one-time NOC is needed
3. If Godown and storing the Scrap, Permanent NOC is needed
[WhatsApp](https://api.whatsapp.com/send?phone=919840703100)[https://api.whatsapp.com/send?phone=919840703100](https://api.whatsapp.com/send?phone=919840703100)



- [ ] ==Subramanian (EDI)==(Type:: Mentors) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

Mobile: 9600453168



- [ ] ==Raja Gopalan==(Type:: Mentors) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

Contact Details (Referred by Subramanian of EDI) - 9600453168 - Ananda Building, no:03, Shop no-10 , Station road, west Mambalam, Chennai
Meeting -1
    Meeting May 16, 2019
    Value add
    -   He can help with the Quality Checking, identifying Suppliers
    -   Focus on Products that have Customers locally
        -   Parrys Corner
            -   Margins are low, but Volumes are more
        -   Super Markets & Local shops
            -   Margins are better
    
    Leather
    
    -   Salt & Raw Leather Materials Trading
        -   African Countries
        -   Good margins 50% possible
    
    Toys, Electrical & Electronics
    -   Imports from China, has a warehouse in China, Inspects the Goods in his warehouse and then ships it to India
    -   Buyers are Shops in Parrys Corner
    -   Selling well currently
    
    PP Granules
    -   Customers in Oragadam, Sriperumbudur, Pallavaram, Tambaram Outer Sanatorium
    -   Major Competitor is Reliance
    -   Selling well currently
    
    Auto Components
    -   Wiring Tape
    -   Plastic LED
    -   Plugs and Cables
    
    Paper
    -   70 GSM
    -   Buyers are Shops in Parrys Corner
    -   Selling well currently
        -   Buying for 160 per real and selling it for 165 per real
    
    Garments
    -   Knitted Garment Materials
        -   China
    -   Bangladesh
        -   Shirt Materials
        -   Inner Wear
December 11, 2019
    -   **Old Corrugated Cartons**
        -   One Container (40ft Hike) can accommodate around 43T of Bales
        -   Shipping Cost is around 250USD from Srilanka to Tuticorin or Chennai.
        -   Ask for CIF quotes from the Suppliers. Customs & Clearance have to be done by us and then sold in the local Markets
        -   Quality Requirements - No Wetness or Moisture or Tissues(No other extraneous products mixed). This is the only Requirement
        -   Pricing
            -   Landed Cost was around 10Rs and sold locally for 13Rs and margins were 2Rs/KG
    -   **Other Products**
        -   **Scraps**
            -   All kinds of Scraps imported are profitable. Most of the Scraps in Developed Countries are given for free and we have to pay only Transportation Charges.
            -   Iron, Copper, Lead, Aluminium, Indene(Pressure Cooker) Scraps are doing well in Chennai
            -   Copper Scraps are imported from Srilanka, but they have no availability. Mostly imported from other countries fraudulently and then reexported to India.
        -   **Spices**
            -   Cardamom - selling locally for 3200/KG. Margins are around 200/KG. His friend is doing the trade
            -   Clove & Cinnamon are also doing well locally. Trading happens in Kerala only and not in Chennai
            -   Shipping is done by Kuruvi's. They are allowed to carry 60KG per trip and they will carry for a commission.
August 7 2020
    Told him to call and come and meet him
    -   Fast Moving
        -   Almonds (US & Dubai)
        -   Dates (US & Dubai)
        -   Toys
    -   Slowed down
        -   Masks & Sanitizer
December 23, 2020
    -   Pulses from Australia
    -   Black Pepper from Sri Lanka
    -   Toys
Feb 4, 2021
    1.  Iron Scrap & OCC are fast moving
    2.  He is currently sending red Chillies Shipment to Srilanka
    3.  He finished importing Pepper from Srilanka last month
## **==General Archived==**
# Tax Related

**==All Contacts==**
- [ ] ==Kannan Auditor==(Type:: Tax) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

M: 9444002946 M: 8939295215
## **==Tax Related Archived==**
# Shipping

**==All Contacts==**
- [ ] ==VASANTHAM TRAANS==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

[https://www.vtlpl.com/contact](https://www.vtlpl.com/contact)



- [ ] ==Triton Shipping==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

- P Satheesh Manager Triton Logistics And Maritime Pt Ltd. Catholic Centre IInd Floor, 64 Armenian Street, Tel.: 44.4343 6400 Mobile: 8754480321 E: [Satheesh_p_che@tritonmaritime.com](mailto:Satheesh_p_che@tritonmaritime.com)
- Jai Karthik, Triton, Mobile: 9884102474 E-mail: ai k [che@tritonmaritime.com](mailto:che@tritonmaritime.com)



- [ ] ==New Globe Logistics==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

[https://api.whatsapp.com/send?phone=919940430788](https://api.whatsapp.com/send?phone=919940430788)
Old Meetings
    -   **Activities**
        -   **Custom Clearance**
        -   **Seal Charge 350**
        -   **Weigtage Charge 250**
        -   **BL Fee 2000**
        -   **Clearance 3500**
        -   **Fumigation NA**
        -   **CFS Charge 4300**
        -   **Transport for 20ft 8500 and 40ft 9500**
        -   **Unloading 1000**
        -   **Sundries**
        -   **Freight Charges for Malaysia and Singapore is NIL**
        -   **THC for 20ft 5000 and 40ft 6500 (THC is NIL for Malaysia and Singapore)**
        -   **Insurance - Small Amount**
    -   **Documents needed** (See [**](https://mail.google.com/mail/u/1/#search/New+Globe+Logistik+LLP/FMfcgxmZTcLCfdcgZPrDvxsXPFFNbdnF)[https://mail.google.com/mail/u/1/#search/New+Globe+Logistik+LLP/FMfcgxmZTcLCfdcgZPrDvxsXPFFNbdnF**](https://mail.google.com/mail/u/1/#search/New+Globe+Logistik+LLP/FMfcgxmZTcLCfdcgZPrDvxsXPFFNbdnF**))
        -   **Packing List**
        -   **Bill**
        -   **Letter of Bond OR GST paid**
        -   **Spice Board Certificate**
    -   **Packaging**
        -   **For 20ft (27T), 55 KG bags around 540 bags per container**
    -   **Documents required**
        -   **Spice board certificate copy for the commodity Red Dry Chillies with validity**
        -   **Drug license certificate for exporting the commodity Turmeric in Powder or Cream form**
        -   **KYC format enclosed and documents copy prescribed in the KYC to be enclosed duly signed & sealed along with the KYC form in original**
        -   **Photo copy of GST registration**
        -   **Photo copy of company PAN Card**
        -   **Photo copy of address proof**
        -   **Photo copy of IEC**
        -   **Photo copy of company incorporation certificate**
        -   **Original shipper invoice – 5 nos (scanned copy by mail to file documents with customs prior to the cargo arrival @ CFS and we will provide the full style of CFS address where the cargo to be moved with contact details).**
        -   **Original shipper packing list – 5 nos (scanned copy by mail )**
        -   **Original Appendix SDF Form on shipper letter head to be duly printed, signed & sealed – 2 Nos**
        -   **Original DBK declaration forms which we will check and let you know the DBK benefit avails for this commodity.**



- [ ] ==Masterstroke Freight Forwarders==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

M. Chandrasekhar Mob +91 93829 33302 Paul 80560 42352 Master stroke Freight Forwarders No.93 (Old No.45) Armenian Street, Tel: 91 44 2521 6464 2521 6465 [www.masterstrokelogistics](http://www.masterstrokelogistics/



- [ ] ==Freight Bridge Logistics==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask 

- We are Serving for both LCL & FCL ( exports & imports ) - SEA & AIR – WORLDWIDE DESTINATION. We promise best services and Rates For AIR & SEA LCL/FCL- IMPORT/EXPORT
- V.Jaikarthik FREIGHTBRIDGE LOGISTICS PVT LTD. No. S-4, 2nd Floor, Reshma Apartments, No.324, MKN Road, Thiruvalluvar Nagar, Alandur, Chennai – 600 016. Tel: +91 44 6460 4201 | Mob: +91 9884102474 E-Mail : [jk@fblindia.in](mailto:jk@fblindia.in) | Website : [www.fblindia.in](http://www.fblindia.in/)



- [ ] ==EasyWay Logistics==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

[](https://easywaylogistics.net/industries/chemicals-plastics-logistics/)[https://easywaylogistics.net/industries/chemicals-plastics-logistics/](https://easywaylogistics.net/industries/chemicals-plastics-logistics/)
[](https://mail.google.com/mail/u/1/#search/easy+way)[https://mail.google.com/mail/u/1/#search/easy+way](https://mail.google.com/mail/u/1/#search/easy+way)
Mobile: +91 9940092997 Email: [info@easywaylogistics.net](mailto:info@easywaylogistics.net
2000 CAD for 20ft Container (13T)
45000 INR for Indian Custom Clearance
30,000 INR Canada Clearance
40000 INR for Transportation from Port to Paper Mill
Duty 15.5%



- [ ] ==CTS Shipping==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

One Container is 20FT (16-18MT) or 40FT (32-35MT) or LCL (You are sharing the container with other customers and hence you can send smaller Weight) FOB is the best, If that’s not possible, Ask for CIe and not CIF as GST on Freight has to be paid by us and it’s better if the buyer would pay those charges as taxes can be avoided.
Freight charges for Malaysia, 5000 approx per tonne = 5 RS per KG, Custom and Inspection and fumigation charges approx 5000/ tonne=5 RS/KG, Other charges 5 RS/KG, Profit and my operating costs approx 1 USD per KG works out to 1000 USD per tonne and 20000 USD per container
	-   **Process Involved**
		-   **Transport from Supplier Godown or yours to CFS + Unloading**
		-   **Inspection and Custom Formalities**
		-   **Transport from CFS to Container + Loading**
		-   **Freight + Insurance**
Documents Needed:
	-   **Invoice**
	-   **Purchase Order**
	-   **Packing List**
	-   **Certification & Fumigation Tests Reports**



- [ ] ==Bergin Prince Bell==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

Mob: 9790594608



- [ ] ==Balmer Lawrie==(Type:: Shipping) #Contacts (LastContacted:: ) (ContactStatus:: )(NextContact:: ) #NotATask

[](http://li.balmerlawrie.com/balmerli/contact)[http://li.balmerlawrie.com/balmerli/contact](http://li.balmerlawrie.com/balmerli/contact)
[Palvannan.pm@balmerlawrie.com](mailto:Palvannan.pm@balmerlawrie.com)
9892560076

## **==Shipping Archived==**
