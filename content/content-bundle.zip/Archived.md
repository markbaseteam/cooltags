---
Status: Archived
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]

# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
# Archived Ideas
```dataview 
TASK 
FROM "Ideas"
WHERE contains(file.name, "Archived")
WHERE Ideas
FLATTEN Ideas
GROUP BY Ideas
SORT Ideas ASC 
```
# Agriculture
## Pulses
- [ ] Pulses (Ideas:: #Agriculture/Pulses) #NotATask 
### Notes
Government Regulations
	Tur, Moong, Urad and Pigeon pea - moved them from ‘restricted’ to ‘free’ with immediate effect till October 31. This liberalised regime would enable seamless and timely import of pulses.
	Prices of urad and tur have firmed up by 10-12 per cent in Myanmar. In Chennai, urad prices for FAQ quality was down by ₹500 at ₹7,100 for the old crop. 
	Stocks of urad and tur are thin in Myanmar as production has been lower with farmers shifting to moong in recent years due to high Chinese demand and price
	yellow peas - Still in Restricted List
Pulses
	-   Urad (Black Gram)
	-   Tur (Pigeon Peas)
	-   Green Peas (Canada)
	-   Masoor Dal (Canada)
	-   **[MAIZE FEED INDUSTRIAL](https://ncdex.com/products/MAIZE)**
	-   Bengal Gram (Tanzania)
	-   Sesame Seeds
	-   **[MOONG](https://ncdex.com/products/MOONG)**
		**[MOONG](https://ncdex.com/products/MOONG)**
	-   **[BAJRA](https://ncdex.com/products/BAJRA)**
		**[BAJRA](https://ncdex.com/products/BAJRA)**
	-   **[CHANA](https://ncdex.com/products/CHANA)**
		**[CHANA](https://ncdex.com/products/CHANA)**
Market News
	The estimates reported by the Ministry of Food Processing Industries show the average value of export of processed food to be $32.8 billion from 2015-16 to 2019-20. The export earnings can go up if India can export value added processed food products rather than the primary processed agricultural commodities. The average export of 48 key agricultural and processed food products (tracked by the (Agricultural and Processed Food Products Export Development Authority, or APEDA) increased from a five-year average of $17.8 billion (from 2015-16 to 2019-20) to $20.65 billion in 2020-21. Most of these items are from agriculture and allied sectors with minimal processing.
	
This increase in the export of non-basmati rice took place despite a huge increase in the procurement (at minimum support price, in the form of paddy) by the government in 2019-20. We also see that rice procurement increased from a five-year average of 41.2 million tonnes to 58.6 million tonnes in 2020-21 (difference between kharif marketing season and financial year is not accounted for). The average unit price realisation per tonne of non-basmati rice was $366.5 in 2020-21 compared to $391.6 in the previous five years. Indian rice is still quoting $40-$50 lower than the comparable Thai rice (25 per cent broken grains)

A major objective of the Agriculture Export Policy 2018 has been to diversify the export basket so that instead of primary products, the export of higher value items, including perishables and processed food, be increased. It is also envisaged that the growing global market of organic and novel agricultural products will be tapped into.

However, the export of processed food products has not been growing fast enough because India lacks comparative advantage in many items. This may imply that the domestic prices of processed food products have been much higher as compared to the world reference prices. Besides, the exporters of processed food confront difficulties and non-tariff measures imposed by other countries on Indian exports. Some of these include:

Mandatory pre-shipment examination by Export Inspection Agency is lengthy and costly

Compulsory spice board certification is needed even in the ready to eat products which contain spices in small quantities

Export shipments to the US require an additional health certificate

Absence of equivalency agreement with developed countries for organic produce

The production-linked incentive (PLI) scheme proposes assistance for the manufacture and export of four major food product segments – ready to cook/eat foods, processed fruits and vegetables, marine products, and mozzarella cheese.

Indian imports from Australia include coal, copper ore and concentrate, gold, vegetables, lentils, fruits, nuts, and wool.

## Cereals
- [ ] Cereals (Ideas:: #Agriculture/Pulses) #NotATask 

Free import of refined oils at least for a limited period is critical. There will be little time lag between import and distribution of refined oils for human consumption, unlike crude oils that need to go through the process of refining before distribution which itself provides a window for speculation. While the government has noted most of the suggestions, it appears likely that duty on edible oil imports may be slashed at least for the next few months. Also, processors, importers and trades will be mandated to declare stocks. Currently, close to 20 lakh tonnes of imported oils are in ports and in pipeline.
1. **[SOYBEAN MEAL](https://ncdex.com/products/SBMEALIDR)**
    **[HIPRO SOYBEAN MEAL](https://ncdex.com/products/SBMEALIDR)**
2. **[SESAME SEEDS](https://ncdex.com/products/SESAMESEED)**
    **[NATURAL WHITISH SESAME SEEDS](https://ncdex.com/products/SESAMESEED)**
3. **[MUSTARD SEED](https://ncdex.com/products/RMSEED)**
    **[MUSTARD SEED](https://ncdex.com/products/RMSEED)**
4. **[CRUDE PALM OIL](https://ncdex.com/products/CPO)**
    **[CRUDE PALM OIL](https://ncdex.com/products/CPO)**
5. **[SOYBEAN](https://ncdex.com/products/SYBEANIDR)**
    **[SOYBEAN](https://ncdex.com/products/SYBEANIDR)**
6. **[REFINED SOY OIL](https://ncdex.com/products/SYOREF)**
    **[REFINED SOY OIL](https://ncdex.com/products/SYOREF)**
7. **[COTTON OILCAKE](https://ncdex.com/products/COCUDAKL)**
    **[COTTON SEED OILCAKE](https://ncdex.com/products/COCUDAKL)**
8. **[CASTOR SEED](https://ncdex.com/products/CASTOR)**
    **[CASTOR SEED](https://ncdex.com/products/CASTOR)**
9. Cereal Preparations
10. Milled products which include mainly various kinds of flour
    Cereal based processed food
11. **[WHEAT](https://ncdex.com/products/WHEATFAQ)**
    **[WHEAT](https://ncdex.com/products/WHEATFAQ)**
12. **[BARLEY](https://ncdex.com/products/BARLEYJPR)**
    **[BARLEY](https://ncdex.com/products/BARLEYJPR)**
13. **[MAIZE FEED INDUSTRIAL](https://ncdex.com/products/MAIZE)*

## Walnuts 
- [ ] Walnuts (Ideas:: #Agriculture/DryNuts) #NotATask 

## Cardamom
- [ ] Cardamom (Ideas:: #Agriculture/DryNuts) #NotATask 

## Jeera & Coriander
- [ ] Jeera & Coriander (Ideas:: #Agriculture/Spices) #NotATask 

## Turmeric
- [ ] Turmeric (Ideas:: #Agriculture/Spices) #NotATask 

## Pepper
- [ ] Pepper (Ideas:: #Agriculture/Spices) #NotATask 
### Notes
Sri Lanka is dumping Vietnam pepper in India. There have been occasions when pepper from Vietnam have come directly to India in ships with bills raised in Sri Lanka to show as if it was grown in the island nation. Since January, 2,759 tonnes of pepper has come from Sri Lanka with the value of imports pegged at Rs 7,000 per tonne. But going by the prices in the domestic market, the actual cost may not be higher than Rs 3,500 a tonne.“ Invoices are being shown at a higher value to beat around the minimum import price. Most of these shipments land in Chennai or Tuticorin ports. Buyers in these countries are importing it from Vietnam and then pushing it into India at a lower duty, taking advantage of the FTAs and other trade agreements.


## GM Deoiled soya cake
- [ ] GM Deoiled soya cake (Ideas:: #Agriculture/Pulses) #NotATask 
### Notes
Raw material in the poultry feed industry.

Soyameal is the protein rich solid left after the oil is expelled from the seed and is used as a raw material for poultry feed. Extremely high prices of soyabean has seen the poultry industry complain about the resultant high price of deoiled soya cake or meal. Used as the protein source in the feed, prices had escalated from the normal Rs 40/kg to Rs 110/kg. Since May, the industry has been seeking import of soya cake, citing the high prices which, they said, had put many small poultry firms out of business. The industry had blamed speculation in the commodity markets for the high prices of the raw material.

The notification has cleared import of 12 lt of crushed and deoiled GM soya cake, with the condition that the imports should arrive before October 31. The DGFT has allowed the import to land only at two ports — Nhava Sheva in Navi Mumbai and Petrapole in West Bengal. India has reported sowing of soyabean over 121.09 lakh hectares this kharif, higher than the 119.91 lakh hectares of sowing last year.

Friday's government order said that besides the Nhava Sheva Port, traders could now import soy meal via the Mumbai Sea Port, the Tuticorin Sea Port, and the Visakhapatnam Sea Port.

Reuters on Wednesday reported that India has contracted to import 2,50,000 tonnes of soy meal, including 15,000 tonnes that Indian dealers had shipped out only two months ago.

## Poultry
- [ ] Poultry (Ideas:: #Agriculture/Animals) #NotATask 
### Notes
With soyabean prices doubling over the past year and maize prices ruling firm, production costs of poultry birds have increased by about 40 per cent. As a result, retail chicken prices have skyrocketed, ruling between ₹260 and ₹300 per kg in various markets across the country. Our cost of production has gone up from around ₹65-70 per kg to currently around ₹110. As a result, the prices of live birds at the farm gate is around ₹118 per kg. Indications that soyabean prices are unlikely to ease significantly going forward and production costs set to remain high are likely to make way for cheaper poultry imports.

Spot soyabean prices in Indore are hovering at around ₹8,700 per quintal. Soyabean futures contract on NCDEX for September ended six per cent higher at ₹8,148 on Friday, while the November contract gained 2.5 per cent at ₹6,150. Soyabean acreages are trailing last year’s levels due to erratic rainfall pattern across Madhya Pradesh, the main producing region, and in other States like Rajasthan and Maharashtra, and the trend may influence the output.

With an import duty of over 30 percent on whole birds and over 100 per cent on cuts/offals, imported chicken would still be cheaper compared to the domestic produce. The frozen chicken legs, considered a waste in the US, are shipped to markets in developing countries. In India, quick service restaurants and fast food chains are considered to be the potential targets for the frozen chicken. Poultry imports into the country have declined 40 per cent during 2020-21 to $3.48 million compared with $5.73 million the previous year. The US accounted for over half of the imports, valued at $1.86 million, followed by France, Germany and Brazil. Frozen poultry imports require creation of infrastructure for distribution. “Also, the imports may not be feasible after two months, when the new crop arrives.
## Food Processing
- [ ] Food Processing (Ideas:: #Agriculture/Fruits-Vegetables) #NotATask 
### Notes
1.  Dairy Products
2.  Vegetable Dehydration
3.  Tofu (Soya Paneer), Soya Milk
4.  Ready-to-eat & Processed Food
5.  Processed Fruit & Vegetables
    There are 39,748 registered food processing units in the country. There are 42 mega food parks in the country
    Mango, potato, citrus, agrochemical
    Minimally processed vegetables. (Onion, garlic and ginger Paste)
    1.  Processed Fruits
        mango, guava, banana, oranges and lemon are available in plenty in Chennai markets coming from the neighboring districts. Squashes, Syrup, jam and jellies from oranges, lemon and mango and mango bar, mango pulp, guava pulp etc. can be made.  
6.  Cocoa Oil & Powder

## Mango Pulp
- [ ] Mango Pulp (Ideas:: #Agriculture/Fruits-Vegetables) #NotATask 


## Fisheries
- [ ] Fisheries (Ideas:: #Agriculture/Animals) #NotATask 
- [ ] Research Import Duties on Shrimp and Input Materials
### Notes
The Union budget announced a sharp reduction of basic customs duty from 30% to 10% on live black tiger shrimp, which farmers use for breeding, and from 30% to 15% on both frozen krill, a feed for fish, and on algal oil derived from certain marine algae for making aquatic feed.

These inputs used in shrimp culture were given relief on basic customs duty as India is a major exporter of shrimps and there are several farms in coastal Andhra Pradesh and Tamil Nadu. To support the food processing sector, the duty on frozen squids and mussels, a shell fish, too was halved to 15%. The finance ministry has reduced import duty only on black tiger shrimp from 30% to 10% which is really commendable and helpful for the aquaculture industry. But right now, more than 95% shrimp import consists of L. Vannamei shrimp. So, it would be highly beneficial if the import duty is reduced on that as well

Kumar said the hatchery industry is heavily dependent on feed necessary for shrimp from other countries, and it would be helpful if the import duty is reduced on that as well since there are relatively less number of indigenous shrimp feed manufacturers. Hatcheries need incentives given that they take the initial high risks of importing live shrimps and have a limited window period for selling to farmers without compromising quality and safety.



# Imports
## Ukraine & Russia
- [ ] Ukraine & Russia (Ideas:: #Imports/Ideas ) #NotATask 

Ukraine - Fertilizer, Corn, Wheat, sand for glass and also for fracking

Russia and Ukraine account for around 29% of global wheat exports, 19% of global corn supplies, and 80% of the world’s sunflower oil exports. This reliance has many traders worried that any further military force could trigger a massive scramble by food importers to replace supplies normally sourced from the Black Sea region. 

Russia is also one of the world’s biggest exporters of all three major groups of fertilizers.

## UAE
- [ ] UAE (Ideas:: #Imports/Ideas ) #NotATask 

**Exports**
- Coconuts
- Cashew Nuts
- Bananas
- Chili Powder
- Rice Parboiled, Basmati, Non Parboiled
- Fibers & Clothing HS Code 61 and 62
- Refined Sugar

**Imports**
- Almonds
- Dry Dates
- Urea
- Metal Scrap (Iron & Aluminium)

## Australia
- [ ] Australia (Ideas:: #Imports/Ideas ) #NotATask 

**Exports**
- Fibers & Clothing HS Code 61 and 62

**Imports**
- Almonds
- Mosur
- Metal Scrap (Iron & Aluminium)




## Mentoring
- [ ] Mentoring (Ideas:: #Imports ) #NotATask 

Mentorship Dates and Timings
    CII - MSME Division Wednesday and Fridays between 3 and 5PM. Free
    TFSC Saturday 10AM Price 3000
    TIE Weekly as announced Price 5500
Industry Associations
    1.  FIEO: [](https://www.fieo.org/)[https://www.fieo.org](https://www.fieo.org)
    2.  ITCOT Consultants - [](http://www.itcot.com/)[http://www.itcot.com/](http://www.itcot.com/)
    3.  KVEC PMEGP Eportal - [](https://www.kviconline.gov.in/pmegpeportal/pmegphome/index.jsp)[https://www.kviconline.gov.in/pmegpeportal/pmegphome/index.jsp](https://www.kviconline.gov.in/pmegpeportal/pmegphome/index.jsp)
    4.  TFSC - [Project Profiles](https://photos.app.goo.gl/tHKru7jiNihecSZw8) and [Services offered](https://photos.app.goo.gl/yZjnxhaiP3m3h1TJ8)
    5.  TIE Mentoring program: [](https://photos.app.goo.gl/FUiuc3cYs8dAtTqd8)[https://photos.app.goo.gl/FUiuc3cYs8dAtTqd8](https://photos.app.goo.gl/FUiuc3cYs8dAtTqd8)
    6.  SIDCO **-** Focus on Councils for Specific Sectors like Export Boards - [](http://dcmsme.gov.in/dips/state_wise_dips/state%20industrial%20profile%20-%20tamil%20nadu_4316.pdf)[http://dcmsme.gov.in/dips/state_wise_dips/state industrial profile - tamil nadu_4316.pdf](http://dcmsme.gov.in/dips/state_wise_dips/state%20industrial%20profile%20-%20tamil%20nadu_4316.pdf)
    7.  Commissionerate of Industries & Commerce (MSME Department) **-** They provide Financing and Land Allocation for MSME. They don't provide Project profiles [Services offered](https://photos.app.goo.gl/2nT6QirT1svX9fH17)
    8.  MSME Development Institute [](https://msme.gov.in/)[https://msme.gov.in/](https://msme.gov.in/)  [](http://www.msmedi-chennai.gov.in/)[http://www.msmedi-chennai.gov.in](http://www.msmedi-chennai.gov.in)
    9.  EDI - [](http://www.editn.in/)[http://www.editn.in/](http://www.editn.in/)
        1.  Health Sugar free restaurants
    10.  CII - MSME Division
    11.  Provide loan and mentoring services for people below 35 years. Focused on manufacturing and services. Retail reading is a small aspect but bankers are not too keen on it. They provide mentoring on Wednesday and Fridays between 3 and 5PM. Free  [](https://photos.app.goo.gl/XFDpgDG2TPrvVcBZ8)[https://photos.app.goo.gl/XFDpgDG2TPrvVcBZ8](https://photos.app.goo.gl/XFDpgDG2TPrvVcBZ8)
    12.  Mathialagan Banker EDI 8668100336 - Referred by Subramanian of EDI 9600453168
IIT Incubation Centre [](http://rtbi.in/)[http://rtbi.in/](http://rtbi.in/) and [](http://www.incubation.iitm.ac.in/home)[http://www.incubation.iitm.ac.in/home](http://www.incubation.iitm.ac.in/home)
    1.  Charles A Arokiamary, 99403 88736. Contact at IIT for incubation. WhatsApp him for a meeting.
        1.  Contact Charles for setting up a meeting
    2.  Read the website fully and come again and WhatsApp him for a meeting.
    3.  Visited their website. All company are product oriented. No block chain related companies in IIT Madras
Coworking Spaces
    1.  **AtWork Perungudi -** No Seats Available
        1.  Visit Temporary Workplace at Perungudi
            1.  What Services do they Provide?
            2.  Are there any Networking Events conducted there?
            3.  How much does it Cost? What are the packages available?
            4.  **Meeting Notes**
                1.  There are no slots available and it's just an apartment with meeting rooms.
                2.  Deepa suggested more workplaces to go and see.
    2.  **The Centre** - [](http://www.thestartupcentre.com/)[http://www.thestartupcentre.com/](http://www.thestartupcentre.com/)
    3.  **IKEVA Workspaces** - [](https://www.ikeva.com/)[https://www.ikeva.com/](https://www.ikeva.com/)
**==All Contacts==**
## Delivery & Quality
- [ ] Delivery & Quality (Ideas:: #Imports) #NotATask 

[Export Documents](https://drive.google.com/open?id=1fmRL3HCVI2ZhFlYRbhlz79jUsprdG08E)
[Export Steps & Financing](https://docs.google.com/document/d/15Y8fROArVH6R578QHZHrpxv4xQQyxE32siHcKHb9iXc/edit)
1.  [Import Data India](https://docs.google.com/spreadsheets/d/1qsn8i8iDHK8_8YwYxX2HWa99X_SLUrhMKRTSlrdEwTE/edit#gid=0)
2.  [ASEAN Trade](https://docs.google.com/spreadsheets/d/1M_LEu9ngMUmgEjxRD2kDAmv94VCfbIoIpIOqwjn8zUA/edit#gid=0)
3.  [Malaysia](https://docs.google.com/spreadsheets/d/1cQfBGdOiBDaNDxSorrpVa5Ismx_ye2DzP0daNVwCgv8/edit#gid=0)
4.  [Singapore](https://docs.google.com/spreadsheets/d/1KjMIdS6F8BTs-Mxx2CokfaWw5tSQW6KyFI7sts2itcw/edit#gid=0)
5.  [Sri Lanka](https://docs.google.com/spreadsheets/d/1m2M1_PIZ92ToOZigrhvj2v2ezlaliSlVq5K5x8lVJes/edit#gid=0)

**==All Contacts==**
# Industrial
## Textiles
- [ ] Textiles (Ideas:: #Retail) #NotATask 
### Notes
-   COIR
    
-   SILK
    
-   ARPETS AND HANDICRAFTS
    
-   Man Made Fibre
    
    Indian apparel exporters are looking to collaborate with global man-made fibre (MMF) suppliers to overcome the supply shortfall in the country and improve domestic production quality.
    
    Indian apparels are predominantly cotton-based. However, the bulk of the global demand is in the MMF segment. The global market for MMF garments is estimated at $500 billion, including $170 billion for sportswear. The share of MMF garments in India’s total apparel exports is only $1.6 billion, or about 10 per cent, whereas the world trade in MMF garments is to the tune of $200 billion.
    
    The Apparel Export Promotion Council (AEPC) has identified man-made fibre-based garments as a sunrise industry due to strong demand in the domestic and international markets.
    
    “As the Indian apparel industry seeks to grab a good share of $200-billion global man-made fibre (MMF)-based garment trade, India companies have sought help from international MMF suppliers to overcome the shortage of the fabric in the short run, and also to improve the quality of local production eventually. There are production facilities in India, but do not have the latest technologies in processing. Indian apparel exporters are keen on a joint venture or technology transfer or 100 per cent investment. Meanwhile, the Indian government has also come out with incentives and initiatives such as establishment of seven mega textile parks to promote MMF production and textile exports.
    
-   Buttons
    
-   **[29 MM COTTON](https://ncdex.com/products/COTTON)**
    
    **[29 MM COTTON](https://ncdex.com/products/COTTON)**
    
-   **[KAPAS](https://ncdex.com/products/KAPAS)**
    
    **[KAPAS](https://ncdex.com/products/KAPAS)**
    
-   Readymade Garments
    
    There is good demand in Countries like Japan, Australia, Switzeland, Honkong,South Africa, Hungary, Latin America, West Asia, New Zealand, and Far Eastern Countries. Following are the main product mix:
    
    (i) Shirt (ii) Ladies Blouse (iii) Jersseys (iv) Pullovers (v) Gent’s shirts (vi) Ladies’ jackets (vii) pyjamas (viii) Night dresses (ix) Glouse and mittens (x) Brassiers (xi) Swi,m wear (xii)Track suits (xiii) industrial and occupational garments (xiv) Bath robes and shorts (xv) children garments etc
    
-   U.F./Nylon buttons
    
    Plastic buttons are mainly manufactured from polyster sheets or acrylic sheets by die punching technique and from Urea formaldehyde moulding powder by compression moulding technique.
    
-   Woven Labels
    
    Since the demand for readymade garments are increasing, the demand for labels will also increase automatically. Few number of units can be established in Chennai as there are only few units in Tamilnadu manufacturing labels. There is good demand for labels also as it is a means of advertisement for tailors and garment exporters.

# Personal

