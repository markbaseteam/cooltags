---
Status: Backlog
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]

# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
# Backlog Ideas
```dataview 
TASK 
FROM "Ideas"
WHERE contains(file.name, "Backlog")
WHERE Ideas
FLATTEN Ideas
GROUP BY Ideas
SORT Ideas ASC 
```
# Agriculture
## Bananas
- [ ] Bananas (Ideas:: #Agriculture/Fruits-Vegetables) (Country:: #UAE ) #NotATask 
## Coconuts
- [ ] Coconuts (Ideas:: #Agriculture/Fruits-Vegetables ) (Country:: #UAE ) #NotATask 
## Cashewnuts
- [ ] Cashewnuts (Ideas:: #Agriculture/DryNuts  ) (Country:: #UAE ) #NotATask 
## Chilly Powder
- [ ] Chilly Powder (Ideas:: #Agriculture/Spices ) (Country:: #UAE ) #NotATask 
## Rice
- [ ] Rice (Ideas:: #Agriculture/Pulses) #NotATask 
### Notes
Non Basmati Rice
**[PADDY (BASMATI) - PUSA 1121](https://ncdex.com/products/PADYPB1121)

## Urea
- [ ] Urea (Ideas:: #Agriculture )(Country:: #UAE ) #NotATask 
# Industrial
## LED Lights
- [ ] LED Lights (Ideas:: #Industrial/Renewables) #NotATask 
- [ ] Decide on the next Steps for LED Lights
- [ ] Decide on the next Steps for Solar Modules
### Notes
Take the case of light emitting diode (LED) makers from India, who now want a complete ban on import of Chinese lights into the country. Presently, about 30 percent of finished products are imported from China in the organised market. However, this figure could be as high as 70 percent in the unorganised sector. At present, there is a 20 percent customs duty imposition on imported LED lighting. The components used for manufacturing LED lights, including drivers and switches like MCPCBs, invite a 10 percent customs duty. The prices of Made in India products are going up because components imported from China are getting expensive. But finished goods from China are flooding the Indian market and online. Sometimes even the country of origin is concealed. The price difference is stark. A regular 9-watt LED bulb manufactured by known brands, costs between Rs 85-90 per piece while those manufactured in China are priced at Rs 20-22, despite the duty. In fact, the lights that pass off as LED from China are, in fact, modified halogen lights. A regular customer won't be able to spot the difference if the package is labeled 'LED'. But energy consumption will be much higher. According to a recent study by ELCOMA, the manufacturers' umbrella body, across three Indian metropolitan cities, 54 per cent of LED brands and 63 per cent of downlighter brands are non-compliant with industry regulations (carrying the name and address of the manufacturer on the product). Moreover, about 80 per cent and 77 per cent of LED and downlighter manufacturers were found to be non-compliant of BIS safety regulations. Such disproportionately high levels of illegal operations diminish the gains that the economy can make from a thriving manufacturing industry. First are the employment losses that are generated as a result of these illegal manufacturers. Such operators either illegally import finished products from China or merely assemble imported parts in India -- reducing any requirement for labour within the country. Such illegal operations tend to distort the pricing of the market as well. Since this segment of the market does not have to incur the cost of compliance or pay any taxes, their costs of operation are lower than the rest of the market. Due to these reasons, products manufactured through the legal route have a price mark-up of about four times in the LED market. (https://raindrop.io/collection/17669814)
## Vinyl Tiles
- [ ] Vinyl Tiles (Ideas:: #Industrial/Construction) #NotATask 
- [ ] Look at IE data for more Information
- [ ] Look at Local domestic Clusters
## Auto Wheeler
- [ ] Auto Wheeler (Ideas:: #Industrial) #NotATask 
### Notes
(https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1765200792)[https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1236246503](https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1236246503)
Import Products & Countries
 Maximum dependence, especially for the two-wheeler and passenger vehicle industry, is in
 1.  Steering systems
 2.  Braking systems
 3.  Engine parts
 4.  Lighting systems
 5.  Electronics and electrical parts
 6.  Fuel injection parts
[Automobiles | Hypothesis](https://hypothes.is/groups/mR76VoVa/automobiles)
(https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1236246503)[https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1236246503](https://docs.google.com/spreadsheets/d/1S-a1QbrNJVQ5AiO21QabNT86tnnCD2-8JucvA5R20Vc/edit#gid=1635073057&fvid=1236246503)
    
    Fully Imported from China

## Construction
- [ ] Construction (Ideas:: #Industrial/Construction) #NotATask 
### Notes
-   M-plaster, gypsum plaster
    M-plaster, gypsum plaster or cement used for plastering, instead of sand and M-Sand
    
    Developers have begun to look at importing certain products like high-end fit-outs and furniture, glass partitions, bathroom fittings, glazing, marble, monitor alarms. They source this mostly from China, the U.S., UAE, Belgium, Italy, Malaysia and Thailand.
    
    Chennai-based group Navin’s imports prefab material from Malaysia and other countries. “Prices are on par with China, where different product ranges are available at varied cost brackets. We import prefab top flooring tiles. Wood is imported from Malaysia and Africa, while finishing material comes from China.
-   Raw materials for making furniture
- 1.  Fiberglass Reinforced Plastics. (FRP)   
	1.  FRP Doors and Window frames
    Composite Technology Centre (COMPTEC), IIT Chennai and RV-TIFAC composite Design Centre have come forward to promote the use of FRP doors as a replacement for wooden doors.

## Leather
- [ ] Leather (Ideas:: #Retail) #NotATask 
### Notes
-   Leather garments (for exports)
-   Ethnic Footwear
-   Leather sandals & Chappals
-   Key holders
-   Leather luggage bags
-   Industrial Hand gloves
-   Leather components like shoe uppers, and shoe bottoms
-   Belts
-   Wallets
-   Hand bags


## Iron Scrap
- [ ] Iron Scrap (Ideas:: #Industrial/Scrap) (Ideas:: #Countries/UAE)  #NotATask 
## Aluminium Scrap
- [ ] Aluminium Scrap (Ideas:: #Industrial/Scrap ) (Ideas:: #Countries/UAE)  #NotATask 
## Fibers and Clothing
- [ ] Fibers and Clothing (Ideas:: #Retail/Clothing) (Ideas:: #Countries/UAE)  #NotATask 
# Personal
# Imports