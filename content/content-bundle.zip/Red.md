
---
Status: Now
cssclass: hidetags
---
```dataview 
LIST 
FROM "Tasks" OR "Ideas"
WHERE !contains(file.name, "Archived") AND !contains(file.name, "Backlog") AND !contains(file.name, "Contacts")
sort file.name ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]
# Ongoing Ideas
```dataview 
TASK
FROM "Ideas"
WHERE Ideas
WHERE contains(Status, "Now")
GROUP BY file.link
sort text ASC
```
[[Archived]]  [[Backlog]]  [[Contacts]]
## Red
- [ ] Red #NotATask  ==2022-05-30==  (Ideas:: #) 
-------------------- 
- [ ] Cool Week 22-2022 (CanvasGroup:: "/") #NotATask - 
- [ ] **Questions** #NotATask 
	- [ ] 1
	- [ ] 2
		- [ ] 3
		- [ ] 4
		- [x] 5 2022-05-30 (13-51)
		- red
		```mermaid
		graph TD
			A
			B
			05-30-13:49:42( Cool is the best)-->
			05-30-13:49:49( We are the best)
			05-30-13:49:42-->A-->B
			05-30-13:50:54( Thanks)-->05-30-13:50:59( Be Nice)
			05-30-13:58:16( red)
		```
- [ ] ==Products== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Regulations== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Customers== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Channels== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Suppliers== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Business Model== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Financial== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Value Chain== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 

- [ ] ==Delivery== Week 22-2022 (CanvasGroup:: "0") #NotATask - 
- [ ] **Questions** #NotATask 
